All rights reserved

please contact simpliciti@outlook.com for anything, we appreciate your feedback.

For updates https://1drv.ms/f/s!AmaHAXM9ZhPhaYN972FkhyTLHO8
